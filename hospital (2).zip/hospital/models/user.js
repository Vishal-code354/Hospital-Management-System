const db = require('../config/db');
const bcrypt = require('bcrypt');

class User {
  static async create(userData) {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const query = "INSERT INTO Users (name, email, password, role) VALUES (?, ?, ?, ?)";
    return db.query(query, [userData.name, userData.email, hashedPassword, userData.role]);
  }

  static async findByEmail(email) {
    const query = "SELECT * FROM Users WHERE email = ?";
    const rows = await db.query(query, [email]);
    return rows[0];
  }

  static async getAll() {
    const query = "SELECT * FROM Users";
    return db.query(query);
  }

  static async getById(id) {
    const query = "SELECT * FROM Users WHERE id = ?";
    const rows = await db.query(query, [id]);
    return rows[0];
  }

  static async update(id, userData) {
    const hashedPassword = userData.password ? await bcrypt.hash(userData.password, 10) : null;
    const query = "UPDATE Users SET name = ?, email = ?, password = COALESCE(?, password), role = ? WHERE id = ?";
    return db.query(query, [userData.name, userData.email, hashedPassword, userData.role, id]);
  }

  static async delete(id) {
    const query = "DELETE FROM Users WHERE id = ?";
    return db.query(query, [id]);
  }
}

module.exports = User;