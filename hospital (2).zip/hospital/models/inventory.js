const db = require('../config/db');

class Inventory {
  static async create(inventoryData) {
    const query = "INSERT INTO Inventory (medicineName, quantity, expiryDate) VALUES (?, ?, ?)";
    return db.query(query, [inventoryData.medicineName, inventoryData.quantity, inventoryData.expiryDate]);
  }

  static async getAll() {
    const query = "SELECT * FROM Inventory";
    return db.query(query);
  }

  static async getById(id) {
    const query = "SELECT * FROM Inventory WHERE id = ?";
    const rows = await db.query(query, [id]);
    return rows[0];
  }

  static async update(id, inventoryData) {
    const query = "UPDATE Inventory SET medicineName = ?, quantity = ?, expiryDate = ? WHERE id = ?";
    return db.query(query, [inventoryData.medicineName, inventoryData.quantity, inventoryData.expiryDate, id]);
  }

  static async delete(id) {
    const query = "DELETE FROM Inventory WHERE id = ?";
    return db.query(query, [id]);
  }
}

module.exports = Inventory;