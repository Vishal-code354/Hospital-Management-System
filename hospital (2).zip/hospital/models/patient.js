const db = require('../config/db');

class Patient {
  static async create(patientData) {
    const query = "INSERT INTO Patients (name, age, gender, contact) VALUES (?, ?, ?, ?)";
    return db.query(query, [patientData.name, patientData.age, patientData.gender, patientData.contact]);
  }

  static async getAll() {
    const query = "SELECT * FROM Patients";
    return db.query(query);
  }

  static async getById(id) {
    const query = "SELECT * FROM Patients WHERE id = ?";
    const rows = await db.query(query, [id]);
    return rows[0];
  }

  static async update(id, patientData) {
    const query = "UPDATE Patients SET name = ?, age = ?, gender = ?, contact = ? WHERE id = ?";
    return db.query(query, [patientData.name, patientData.age, patientData.gender, patientData.contact, id]);
  }

  static async delete(id) {
    const query = "DELETE FROM Patients WHERE id = ?";
    return db.query(query, [id]);
  }
}

module.exports = Patient;