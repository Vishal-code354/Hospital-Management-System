const db = require('../config/db');

class Appointment {
  static async create(appointmentData) {
    const query = "INSERT INTO Appointments (patientId, doctorId, date) VALUES (?, ?, ?)";
    return db.query(query, [appointmentData.patientId, appointmentData.doctorId, appointmentData.date]);
  }

  static async getAll() {
    const query = "SELECT * FROM Appointments";
    return db.query(query);
  }
}

module.exports = Appointment;