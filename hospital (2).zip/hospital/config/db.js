const sql = require('msnodesqlv8');

// Connection string for SQL Server
const connectionString = "Server=LAPTOP-JPB3I484\\SQLEXPRESS;Database=HospitalDB;Trusted_Connection=Yes;Driver={SQL Server Native Client 11.0}";

// Database connection object with query method
const db = {
  query: (sqlQuery, params) => {
    return new Promise((resolve, reject) => {
      sql.open(connectionString, (err, conn) => {
        if (err) {
          console.error('Database connection error:', err);
          return reject(err);
        }
        conn.query(sqlQuery, params || [], (err, rows) => {
          if (err) {
            console.error('Database query error:', err);
            conn.close();
            return reject(err);
          }
          resolve(rows);
          conn.close(); // Close connection after query
        });
      });
    });
  },
  connect: () => {
    return new Promise((resolve, reject) => {
      sql.open(connectionString, (err, conn) => {
        if (err) {
          console.error('Database connection error:', err);
          return reject(err);
        }
        console.log('Connected to database');
        conn.close(); // Close after testing
        resolve();
      });
    });
  }
};

// Test connection on startup
db.connect()
  .then(() => console.log('Database connection established'))
  .catch(err => console.error('Failed to connect to database:', err));

module.exports = db;