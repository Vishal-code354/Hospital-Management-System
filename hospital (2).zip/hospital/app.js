const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const db = require('./config/db');
const app = express();
const path = require('path');


app.set('views', path.join(__dirname, 'views'));
// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.use(session({
  secret: 'hospital-secret',
  resave: false,
  saveUninitialized: false
}));

// Routes
const adminRoutes = require('./routes/adminroutes');
const doctorRoutes = require('./routes/doctorroutes');
const medicalStoreRoutes = require('./routes/medicalstoreroutes');
const receptionistRoutes = require('./routes/recptionistroutes');

app.use('/admin', adminRoutes);
app.use('/doctor', doctorRoutes);
app.use('/medical', medicalStoreRoutes);
app.use('/receptionist', receptionistRoutes);

// Login Route
const User = require('./models/user');
app.get('/', (req, res) => res.render('login'));
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = await User.findByEmail(email);
      console.log('User:', user); // Debugging
  
      if (!user) {
        console.log('User not found');
        return res.redirect('/');
      }
  
      const passwordMatch = await bcrypt.compare(password, user.password);
      console.log('Password match:', passwordMatch); // Debugging
  
      if (!passwordMatch) {
        console.log('Incorrect password');
        return res.redirect('/');
      }
  
      req.session.user = user;
      console.log('Session user:', req.session.user); // Debugging
  
      // Redirect based on role
      switch (user.role) {
        case 'admin':
          console.log('Redirecting to /admin/dashboard');
          return res.redirect('/admin/dashboard');
        case 'doctor':
          console.log('Redirecting to /doctor/dashboard');
          return res.redirect('/doctor/dashboard');
        case 'medical':
          console.log('Redirecting to /medical/dashboard');
          return res.redirect('/medical/dashboard');
        case 'receptionist':
          console.log('Redirecting to /receptionist/dashboard');
          return res.redirect('/receptionist/dashboard');
        default:
          console.log('Invalid role');
          return res.redirect('/');
      }
    } catch (err) {
      console.error('Login error:', err);
      res.redirect('/');
    }
  });
  

app.get('/logout', (req, res) => {
  console.log("logout succesfully")
  req.session.destroy();
  res.redirect('/');
});

// Error Handling Middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Start server only after DB connection
db.connect()
  .then(() => {
    app.listen(3000, () => {
      console.log('http://localhost:3000');
    });
  })
  .catch(err => {
    console.error('Server failed to start due to database connection error:', err);
    process.exit(1);
  });