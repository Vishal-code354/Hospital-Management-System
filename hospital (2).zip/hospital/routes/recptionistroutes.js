const express = require('express');
const router = express.Router();
const receptionistController = require('../controllers/receptionistcontroller');

router.get('/dashboard', receptionistController.getDashboard);
router.post('/add-patient', receptionistController.addPatient);
router.get('/edit-patient/:id', receptionistController.getEditPatient);
router.post('/update-patient/:id', receptionistController.updatePatient);
router.get('/delete-patient/:id', receptionistController.deletePatient);
router.post('/add-appointment', receptionistController.addAppointment);

module.exports = router;