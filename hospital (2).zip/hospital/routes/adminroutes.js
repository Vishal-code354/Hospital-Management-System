const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admincontroller');

router.get('/dashboard', adminController.getDashboard);
router.post('/add-user', adminController.addUser);
router.get('/edit-user/:id', adminController.getEditUser);
router.post('/update-user/:id', adminController.updateUser);
router.get('/delete-user/:id', adminController.deleteUser);

module.exports = router;