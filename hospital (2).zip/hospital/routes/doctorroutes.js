const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctorcontroller');

router.get('/dashboard', doctorController.getDashboard);

module.exports = router;