const express = require('express');
const router = express.Router();
const medicalStoreController = require('../controllers/medicalstorecontroller');

router.get('/dashboard', medicalStoreController.getDashboard);
router.post('/add-medicine', medicalStoreController.addMedicine);
router.get('/edit-medicine/:id', medicalStoreController.getEditMedicine);
router.post('/update-medicine/:id', medicalStoreController.updateMedicine);
router.get('/delete-medicine/:id', medicalStoreController.deleteMedicine);

module.exports = router;