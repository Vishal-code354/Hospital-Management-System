const Inventory = require('../models/inventory');

exports.getDashboard = async (req, res) => {
  if (req.session.user.role !== 'medical') return res.redirect('/');
  const inventory = await Inventory.getAll();
  res.render('medicalStore/dashboard', { user: req.session.user, inventory });
};

exports.addMedicine = async (req, res) => {
  const inventoryData = {
    medicineName: req.body.medicineName,
    quantity: req.body.quantity,
    expiryDate: req.body.expiryDate
  };
  await Inventory.create(inventoryData);
  res.redirect('/medical/dashboard');
};

exports.getEditMedicine = async (req, res) => {
  const medicine = await Inventory.getById(req.params.id);
  res.render('medicalStore/editMedicine', { user: req.session.user, medicine });
};

exports.updateMedicine = async (req, res) => {
  const inventoryData = {
    medicineName: req.body.medicineName,
    quantity: req.body.quantity,
    expiryDate: req.body.expiryDate
  };
  await Inventory.update(req.params.id, inventoryData);
  res.redirect('/medical/dashboard');
};

exports.deleteMedicine = async (req, res) => {
  await Inventory.delete(req.params.id);
  res.redirect('/medical/dashboard');
};