const User = require('../models/user');

exports.getDashboard = async (req, res) => {
  if (req.session.user.role !== 'admin') return res.redirect('/');
  const users = await User.getAll();
  res.render('admin/dashboard', { user: req.session.user, users });
};

exports.addUser = async (req, res) => {
  const userData = {
    name: req.body.name,
    email: req.body.email,
    password: req.body.password,
    role: req.body.role
  };
  await User.create(userData);
  res.redirect('/admin/dashboard');
};

exports.getEditUser = async (req, res) => {
  const userToEdit = await User.getById(req.params.id);
  res.render('admin/editUser', { user: req.session.user, userToEdit });
};

exports.updateUser = async (req, res) => {
  const userData = {
    name: req.body.name,
    email: req.body.email,
    password: req.body.password || null,
    role: req.body.role
  };
  await User.update(req.params.id, userData);
  res.redirect('/admin/dashboard');
};

exports.deleteUser = async (req, res) => {
  await User.delete(req.params.id);
  res.redirect('/admin/dashboard');
};