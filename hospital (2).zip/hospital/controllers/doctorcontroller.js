const Patient = require('../models/patient');
const Appointment = require('../models/appointment');

exports.getDashboard = async (req, res) => {
  if (req.session.user.role !== 'doctor') return res.redirect('/');
  const appointments = await Appointment.getAll();
  res.render('doctor/dashboard', { user: req.session.user, appointments });
};