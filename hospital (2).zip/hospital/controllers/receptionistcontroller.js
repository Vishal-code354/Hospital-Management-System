const Patient = require('../models/patient');
const Appointment = require('../models/appointment');

exports.getDashboard = async (req, res) => {
  if (req.session.user.role !== 'receptionist') return res.redirect('/');
  const patients = await Patient.getAll();
  res.render('receptionist/dashboard', { user: req.session.user, patients });
};

exports.addPatient = async (req, res) => {
  const patientData = {
    name: req.body.name,
    age: req.body.age,
    gender: req.body.gender,
    contact: req.body.contact
  };
  await Patient.create(patientData);
  res.redirect('/receptionist/dashboard');
};

exports.getEditPatient = async (req, res) => {
  const patient = await Patient.getById(req.params.id);
  res.render('receptionist/editPatient', { user: req.session.user, patient });
};

exports.updatePatient = async (req, res) => {
  const patientData = {
    name: req.body.name,
    age: req.body.age,
    gender: req.body.gender,
    contact: req.body.contact
  };
  await Patient.update(req.params.id, patientData);
  res.redirect('/receptionist/dashboard');
};

exports.deletePatient = async (req, res) => {
  await Patient.delete(req.params.id);
  res.redirect('/receptionist/dashboard');
};

exports.addAppointment = async (req, res) => {
  const appointmentData = {
    patientId: req.body.patientId,
    doctorId: req.body.doctorId,
    date : new Date(req.body.date)
  };
  console.log(req.body.Date)
  await Appointment.create(appointmentData);
  res.redirect('/receptionist/dashboard');
};